package com.example.firebaseauth

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.firebaseauth.R

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private val sampleData = listOf(
        Attraction("Petronas Twin Towers", "The iconic twin skyscrapers in Kuala Lumpur, standing at 452 meters.", "Modern Architecture", R.drawable.petronas),
        Attraction("Batu Caves", "A limestone hill with caves and Hindu temples located near Kuala Lumpur.", "Cultural Site", R.drawable.batucaves),
        Attraction("Langkawi Island", "An archipelago of 99 islands known for its stunning beaches and natural beauty.", "Nature", R.drawable.langkawi),
        Attraction("Mount Kinabalu", "The highest peak in Malaysia, located in the state of Sabah.", "Nature", R.drawable.mountkinabalu),
        Attraction("George Town, Penang", "A UNESCO World Heritage site known for its colonial architecture and vibrant street art.", "Historical Site", R.drawable.georgetown),
        Attraction("Taman Negara National Park", "A vast rainforest with diverse flora and fauna, ideal for eco-tourism.", "Nature",R.drawable.tamannegara),
        Attraction("Sultan Abdul Samad Building", "An iconic historical building in Kuala Lumpur with Moorish architectural style.", "Historical Site",R.drawable.sasbuilding),
        Attraction("Melaka (Malacca)", "A city rich in history with colonial buildings, forts, and museums.", "Historical Site", R.drawable.melaka),
        Attraction("Perhentian Islands", "Beautiful tropical islands perfect for snorkeling and diving, located off the coast of Terengganu.", "Nature", R.drawable.stopisland),
        Attraction("Putrajaya", "A planned city known for its modern architecture, including the Putra Mosque and Putrajaya Lake.", "Modern Architecture", R.drawable.putrajaya)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.rvAttractions)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = AttractionAdapter(sampleData)
    }
}
