package com.example.firebaseauth
data class Attraction(
    val name: String,
    val description: String,
    val category: String,

    val imageRes: Int
)
