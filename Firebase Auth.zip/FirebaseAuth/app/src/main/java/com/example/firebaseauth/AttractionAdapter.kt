package com.example.firebaseauth

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.firebaseauth.R

class AttractionAdapter(
    private val items: List<Attraction>
) : RecyclerView.Adapter<AttractionAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val imageView    = view.findViewById<ImageView>(R.id.ivAttraction)
        private val nameTxt      = view.findViewById<TextView>(R.id.tvName)
        private val descTxt      = view.findViewById<TextView>(R.id.tvDescription)
        private val categoryTxt  = view.findViewById<TextView>(R.id.tvCategory)

        fun bind(attraction: Attraction) {
            imageView.setImageResource(attraction.imageRes)    // bind drawable
            nameTxt.text     = attraction.name
            descTxt.text     = attraction.description
            categoryTxt.text = "Category: ${attraction.category}"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_attraction, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position])
    }
}
